﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace FileDownloading
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                #region FileDownloading
                String dirFTPLocalDownloading = "ftp://192.168.1.110:24/Downloading";    //Example
                String UserId = "sajjad";
                String Password = "admin123";
                String CurrentFileName = "D:\\Sajjad\\Download.txt";///////////// You Should Create path first  downloading form server
                FtpWebRequest requestdownloading = (FtpWebRequest)FtpWebRequest.Create(dirFTPLocalDownloading);
                requestdownloading.Credentials = new NetworkCredential(UserId, Password);
                requestdownloading.Method = WebRequestMethods.Ftp.DownloadFile;
                FtpWebResponse response = (FtpWebResponse)requestdownloading.GetResponse();
                Stream responseStream = response.GetResponseStream();
                StreamReader reader = new StreamReader(responseStream);
                using (FileStream writer = new FileStream(dirFTPLocalDownloading + CurrentFileName, FileMode.Create))
                {

                    long length = response.ContentLength;
                    int bufferSize = 500000;
                    int readCount;
                    byte[] buffer = new byte[500000];

                    readCount = responseStream.Read(buffer, 0, bufferSize);
                    while (readCount > 0)
                    {
                        writer.Write(buffer, 0, readCount);
                        readCount = responseStream.Read(buffer, 0, bufferSize);
                    }
                }

                reader.Close();
                response.Close();
            }


            catch (Exception ex)
            {
                //Connection issue
            }
                #endregion
            
        }
    }
}
