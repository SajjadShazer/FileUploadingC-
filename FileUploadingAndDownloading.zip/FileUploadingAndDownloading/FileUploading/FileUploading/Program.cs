﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace FileUploading
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                #region FileUploading
                String FileNamePathForUploading="ftp://192.168.1.103:24/Active";    //Example
                    String UserId="sajjad";
                        String Password="admin123";
                     String file="D:\\Sajjad\\Test.txt";///////////// You Should Create path first
                        string filename = Path.GetFileName(file);
                        byte[] data = File.ReadAllBytes(file);
                         FtpWebRequest ftpforonelink = (FtpWebRequest)FtpWebRequest.Create(FileNamePathForUploading);
                        ftpforonelink.Credentials = new NetworkCredential(UserId,Password);
                        ftpforonelink.Method = WebRequestMethods.Ftp.UploadFile;
                        ftpforonelink.ContentLength = data.Length;
                        using (Stream requestStream = ftpforonelink.GetRequestStream())
                        {
                            requestStream.Write(data, 0, data.Length);
                        }
                       //After Successful Connection file downloading Done.
                    }
            catch(Exception ex)
            {
                //Connection issue
            }
                #endregion
        }

        }
    }

